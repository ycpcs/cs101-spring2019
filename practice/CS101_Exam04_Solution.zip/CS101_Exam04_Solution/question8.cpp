#include <stdio.h>

struct Point {
	double x, y;
};

struct Velocity {
	double dx, dy;
};

struct Pixel {
	int red;
	int green;
	int blue;
	struct Point location;
	struct Velocity velocity;
};

void reverse_pixel_dir(struct Pixel *p);

int main(void) {
	// IMPORTANT: do not modify any of the code in the main function.
	// If you do you will not receive any credit for this question.

	struct Pixel pixel;

	// Initialize the struct Pixel instance
	pixel.red = 246;
	pixel.green = 141;
	pixel.blue = 171;
	pixel.location.x = 55.4;
	pixel.location.y = 10.3;
	pixel.velocity.dx = -4.5;
	pixel.velocity.dy = 5.2;

	printf("Original pixel velocity: dx=%.2lf, dy=%.2lf\n",
		pixel.velocity.dx, pixel.velocity.dy);

	reverse_pixel_dir(&pixel);

	printf("Updated pixel velocity: dx=%.2lf, dy=%.2lf\n",
		pixel.velocity.dx, pixel.velocity.dy);

	return 0;
}

// TODO: write a definition for the reverse_pixel_dir function
void reverse_pixel_dir(struct Pixel *p) {
	p->velocity.dx *= -1;
	p->velocity.dy *= -1;
}
