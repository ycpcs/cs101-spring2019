#include <stdio.h>

int main(void) {
	// TODO: add your code here
	int n;
	printf("Enter a positive integer: ");
	scanf("%i", &n);

	int sum = 0;
	for (int i = 1; i <= n; i++) {
		int odd = (i * 2) - 1;
		sum = sum + odd;
	}
	printf("Sum is %i\n", sum);

	return 0;
}
